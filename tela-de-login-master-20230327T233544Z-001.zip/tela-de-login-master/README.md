# tela-de-login
Tela de login super simples, porém muito funcional ;) Utilizamos apenas HTML e CSS

Temos uma aula no YouTube ensinando passo a passo, como fazer essa tela de login

<img src='https://1.bp.blogspot.com/-jmCY3sfc6hE/YCU_DEL7_QI/AAAAAAAAAnM/wRA62o6oa4gwKUxiuz6lf32HiqW4KUD2wCLcBGAsYHQ/s320/telalogin.png'>

https://www.youtube.com/watch?v=lP-XV2wXXQM&t
